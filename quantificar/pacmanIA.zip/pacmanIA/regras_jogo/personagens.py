from enum import Enum

class Personagens(Enum):
    JOGADOR_PACMAN = "JogadorPacman"