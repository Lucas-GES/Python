from ambiente import Ambiente
from actions import Actions
import queue
import os

class AgenteBFS():   
      
    def exec():    
        nums = queue.Queue()
        nums.put("")
        add = ""
        ambiente = Ambiente.get_labirinto()

        while not Ambiente.game_over():
            add = nums.get()
            for j in ["a", "d", "w", "s"]:
                put = add + j
                acao = list(put)
                for i in acao:                                
                    Actions.atualizarEstado(i)
                    Ambiente.print_labirinto()
                    os.system('cls||clear')
                nums.put(put)
                   
                